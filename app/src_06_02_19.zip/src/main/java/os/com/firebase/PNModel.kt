package os.com.firebase

class PNModel {
    var type:String?=null
    var body:String?= null
    var title:String?= null
    var badge_count:String?= null
}