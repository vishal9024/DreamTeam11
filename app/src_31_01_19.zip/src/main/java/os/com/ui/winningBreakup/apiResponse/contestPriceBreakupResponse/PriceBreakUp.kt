package os.com.ui.winningBreakup.apiResponse.contestPriceBreakupResponse

class PriceBreakUp()  {
    var rank: String = ""
    var price: String = ""
}