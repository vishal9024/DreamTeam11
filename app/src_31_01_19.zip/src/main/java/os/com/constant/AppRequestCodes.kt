package os.com.constant

/**
 * Created by heenas on 3/23/2018.
 */
object AppRequestCodes {
    const val CLONE=1
    const val EDIT=2
    const val UPDATEVIEW=3
    const val UPDATE_ACTIVITY=5
    const val ADD_CASH=7
    const val CREATE = 0
    const val JOIN = 11
}