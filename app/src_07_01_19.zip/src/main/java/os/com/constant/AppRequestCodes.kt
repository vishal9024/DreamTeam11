package os.com.constant

/**
 * Created by monikab on 3/23/2018.
 */
object AppRequestCodes {

    const val PLACE_AUTOCOMPLETE_REQUEST_CODE =1
    const val DELIVER_ADDRESS_REQUEST_CODE =2
    const val CAMERA_REQUEST_CODE =3
    const val GALARY_REQUEST_CODE =4
    const val TRANSFER_LOYALTY_POINT_CODE =5

    const val APPLY_COUPON_CODE =6
    const val RESCHEDULE_ORDER =9
     const val BARCODE_REQUEST=7
    const val PAYMENT_REQUEST_CODE=0
    const val ADD_MONEY_REQUEST_CODE=11
    const val UPDATE_ADDRESS=12
    const val REQUEST_CODE_BRAIN_TREE=15

}