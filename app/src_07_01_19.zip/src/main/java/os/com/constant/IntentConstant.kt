package os.com.constant

/**
 * Created by monikab on 2/21/2018.
 */
object IntentConstant {
    const  val DATA="DATA"
    const  val OTP="OTP"
    const  val USER_ID="USER_ID"
    const  val MOBILE="MOBILE"


    const val FROM = "FROM"
}