package os.com.ui.createTeam.apiRequest

class SwitchTeamRequest {
    var user_id:String=""
    var match_id:String=""
    var series_id:String=""
    var contest_id:String=""
    var language:String=""
    var team_id:ArrayList<String>?=null
}