package os.com.ui.createTeam.apiRequest

class CreateTeamRequest {

    var user_id:String=""
    var language:String=""
    var match_id:String=""
    var series_id:String=""
    var team_id:String=""
    var captain:String=""
    var vice_captain:String=""
    var substitute:String=""
    var player_id:ArrayList<String>?=null
}