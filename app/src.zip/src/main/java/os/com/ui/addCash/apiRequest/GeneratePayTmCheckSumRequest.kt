package os.com.ui.addCash.apiRequest

class GeneratePayTmCheckSumRequest {
    var MID = ""
    var ORDER_ID = ""
    var CUST_ID = ""
    var MOBILE_NO = ""
    var EMAIL = ""
    var CHANNEL_ID = ""
    var TXN_AMOUNT = ""
    var WEBSITE = ""
    var INDUSTRY_TYPE_ID = ""
    var CALLBACK_URL = ""
//    var CHECKSUMHASH = ""
}