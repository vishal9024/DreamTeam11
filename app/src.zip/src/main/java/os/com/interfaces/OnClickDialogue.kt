package os.com.interfaces

interface OnClickDialogue {
    fun onClick(tag: String, success: Boolean)
}
