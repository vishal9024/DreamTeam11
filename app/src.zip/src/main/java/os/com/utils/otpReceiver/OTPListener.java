package os.com.utils.otpReceiver;

public interface OTPListener {

    public void otpReceived(String messageText);
}