package os.com.ui.joinedContest.apiResponse.joinedContestFixtureListResponse

class PriceBreakUp()  {
    var rank: String = ""
    var price: String = ""
}