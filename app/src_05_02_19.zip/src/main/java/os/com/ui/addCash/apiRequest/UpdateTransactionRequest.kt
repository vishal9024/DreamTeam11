package os.com.ui.addCash.apiRequest

class UpdateTransactionRequest {
    var user_id = ""
    var language = ""
    var order_id = ""
    var txn_id = ""
    var banktxn_id = ""
    var txn_date = ""
    var txn_amount = ""
    var currency = ""
    var gateway_name=""
    var checksum = ""
}