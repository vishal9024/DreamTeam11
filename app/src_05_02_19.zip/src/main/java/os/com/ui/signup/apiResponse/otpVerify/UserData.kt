package os.com.ui.signup.apiResponse.otpVerify

class UserData() {
    var id: String = ""
    var first_name: String = ""
    var last_name: String = ""
    var role_id: String = ""
    var gender: String = ""
    var email: String = ""
    var phone: String = ""
    //    var password: String = ""
    var status: String = ""
    var address: String = ""
    var date_of_bith: String = ""
    //    var image: String = ""
    var refer_id: String = ""
    var fb_id: String = ""
    var google_id: String = ""
    var otp: String = ""
    //    var module_access: String = ""
    var is_login: String = ""
    //    var last_login: String = ""
//    var current_password: String = ""
    var language: String = ""
    var device_id: String = ""
    var device_type: String = ""
    //    var created: String = ""
//    var modified: String = ""
    var user_id: String = ""
    var full_name: String = ""



}