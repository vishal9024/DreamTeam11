package os.com.ui.dashboard.profile.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.nostra13.universalimageloader.core.ImageLoader
import kotlinx.android.synthetic.main.item_freind_list.view.*
import os.com.R
import os.com.application.FantasyApplication
import os.com.ui.invite.apiResponse.InviteFreindDetailResponse


class FriendListAdapter(
    val mContext: Context,
    val rankingList: MutableList<InviteFreindDetailResponse.ResponseBean.DataBean.FriendDetailBean>
) : RecyclerView.Adapter<FriendListAdapter.AppliedCouponCodeHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppliedCouponCodeHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_freind_list, parent, false)
        return AppliedCouponCodeHolder(view)
    }

    override fun onBindViewHolder(holder: AppliedCouponCodeHolder, position: Int) {
        try {
            if (rankingList[position].image != null && !rankingList[position].image.equals(""))
                ImageLoader.getInstance().displayImage(
                    rankingList[position].image,
                    holder.itemView.cimg_user,
                    FantasyApplication.getInstance().options
                )
            if (rankingList[position].team_name != null)
                holder.itemView.txtTeamName.text = rankingList[position].team_name
            if (rankingList[position].received_amount != null)
                holder.itemView.txtReceivedAmount.text = "₹" + rankingList[position].received_amount
            if (rankingList[position].total_amount != null) {
                holder.itemView.txtEarnAmount.text = "₹ " + rankingList[position].total_amount
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun getItemCount(): Int {
        return rankingList.size
    }

    inner class AppliedCouponCodeHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {


    }


}