package os.com.constant

/**
 * Created by heenas on 2/21/2018.
 */
object IntentConstant {
    const val TEAM_ID = "TEAM_ID"
    const val DATA = "DATA"
    const val OTP = "OTP"
    const val ISEDIT = "OTP"
    const val MATCH = "MATCH"
    const val USER_ID = "USER_ID"
    const val MOBILE = "MOBILE"
    const val CONTEST_TYPE = "CONTEST_TYPE"
    const val FIXTURE = 1
    const val COMPLETED = 3
    const val LIVE = 2
    const val SELECT_PLAYER = "SELECT_PLAYER"
    const val WK = "WK"
    const val BOWLER = "BOWLER"
    const val AR = "AR"
    const val BATSMEN = "BATSMEN"
    const  val CONTEST_ID="CONTEST_ID"
    const val CREATE_OR_JOIN = "CREATE_OR_JOIN"
    const val FOR = "FOR"
    const val FROM = "FROM"
    const val CONTEST = "CONTEST"
}