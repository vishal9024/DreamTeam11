package os.com.interfaces

interface OnClickRecyclerView {
    fun onClickItem(tag: String, position: Int)

}
