package os.com.interfaces

interface OnClickCVC {
    fun onClick(tag: String,type:Int ,position: Int)
}
